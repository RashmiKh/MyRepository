package com.cybage.dao;

import java.util.List;
import com.cybage.model.Release;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;

public interface HomeDaoL
{
	List<Release> fingAllRelease();
	/*List<Category> getCategories();
	Integer saveCategory(Category category);*/
	List<ReleaseStatus> getRelesaseStatus();
	List<ReleaseType> getReleaseType();
	List<ReleaseTo> getReleaseTo();
}
