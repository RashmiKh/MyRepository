package com.cybage.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.model.IterationStatus;
import com.cybage.model.IterationType;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;
import com.cybage.model.User;
import com.cybage.model.UserRole;

@Repository
@Transactional
public class HomeDaoImpl implements HomeDao {

	@Autowired
	private SessionFactory factory;
	
	public HomeDaoImpl() {
		System.out.println("HomeDaoImpl Ctor");
	}

	@Override
	public String saveUser(UserRole userRole) {
		System.out.println("Dao : " + userRole);
		Session session = factory.getCurrentSession();
		
		session.save(userRole.getUser());
		
		return (String)session.save(userRole);
	}
	
	
	
	@Override
	public User getUser(String id) {
		
		return (User)factory.getCurrentSession().get(User.class, id);
	}

	//Release Reference Data
	@Override
	public void addReleaseToData(ReleaseTo releaseTo) {
		factory.getCurrentSession().save(releaseTo);
		
	}

	@Override
	public void addReleaseStatus(ReleaseStatus releaseStatus) {
		factory.getCurrentSession().save(releaseStatus);
		
	}

	@Override
	public void addReleaseType(ReleaseType releaseType) {
		factory.getCurrentSession().save(releaseType);
		
	}

	//Iteration Reference Data
	@Override
	public void addIterationStatus(IterationStatus iterationStatus) {
		factory.getCurrentSession().save(iterationStatus);
		
	}

	@Override
	public void addIteraionType(IterationType iterationType) {
		factory.getCurrentSession().save(iterationType);
		
	}
	
		
}
