package com.cybage.dao;

import java.util.List;

import javax.transaction.Transactional;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cybage.model.Release;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;

@Repository
@Transactional
public class HomeDaoImplL implements HomeDaoL
{
	@Autowired
	private SessionFactory factory;	
	
	public HomeDaoImplL() {
		System.out.println("Dao");
	}

	@Override
	public List<Release> fingAllRelease() 
	{	/*		
		Session session = factory.getCurrentSession();		
		Query q = session.createQuery("from Release");
		List<Release> releaseList = q.list(); 
	    return releaseList;*/
		return factory.getCurrentSession().createQuery("SELECT r from Release r").list();
	}

	@Override
	public List<ReleaseType> getReleaseType() 
	{
		return factory.getCurrentSession().createQuery("SELECT r from ReleaseType r").list();
	}

	@Override
	public List<ReleaseTo> getReleaseTo() 
	{
		return factory.getCurrentSession().createQuery("SELECT r from ReleaseTo r").list();
	}

	@Override
	public List<ReleaseStatus> getRelesaseStatus()
	{
		return factory.getCurrentSession().createQuery("SELECT r from ReleaseStatus r").list();		
	}
	/*@Override
	public List<Category> getCategories() 
	{
		return factory.getCurrentSession().createQuery("SELECT r from Category r").list();
	}

	@Override
	public Integer saveCategory(Category category) 
	{
		Integer id=(Integer) factory.getCurrentSession().save(category);
		return id;
		
	}*/

}
