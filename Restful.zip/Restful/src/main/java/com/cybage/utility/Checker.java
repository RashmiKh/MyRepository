package com.cybage.utility;

public class Checker {
	 public static void main(String[] args) throws Exception {

	        String password = "Sameerasdfasdfsdfasdfasdfasdasd";
	        String passwordEnc = AESencrypt.encrypt(password);
	        String passwordDec = AESencrypt.decrypt(passwordEnc);

	        System.out.println("Plain Text : " + password);
	        System.out.println("Password Length : " + password.length());
	        System.out.println("Encrypted Length : " + passwordEnc.length());
	        System.out.println("Encrypted Text : " + passwordEnc);
	        System.out.println("Decrypted Text : " + passwordDec);
	    }
}
