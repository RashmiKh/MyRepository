package com.cybage.model;

import java.io.Serializable;
import javax.persistence.*;


@Entity
@Table(name="releaseiteration")
public class ReleaseIteration implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	//bi-directional many-to-one association to Iteration
	@ManyToOne
	@JoinColumn(name="ITERATIONID", referencedColumnName = "ID")
	private Iteration iteration;

	//bi-directional many-to-one association to Release
	@ManyToOne
	@JoinColumn(name="RELEASEID", referencedColumnName = "ID")
	private Release release;
	
	public ReleaseIteration() {
	}

	public ReleaseIteration(String id, Iteration iteration, Release release) {
		super();
		this.id = id;
		this.iteration = iteration;
		this.release = release;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Iteration getIteration() {
		return this.iteration;
	}

	public void setIteration(Iteration iteration) {
		this.iteration = iteration;
	}

	public Release getRelease() {
		return this.release;
	}

	public void setRelease(Release release) {
		this.release = release;
	}

	@Override
	public String toString() {
		return "ReleaseIteration [id=" + id + ", iteration=" + iteration + ", release=" + release + "]";
	}

}