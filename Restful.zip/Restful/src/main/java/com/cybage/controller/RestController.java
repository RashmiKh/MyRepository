package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.UriComponentsBuilder;


import com.cybage.model.Release;
import com.cybage.model.ReleaseItem;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;
import com.cybage.service.HomeServiceL;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/home")
public class RestController 
{
	@Autowired
	HomeServiceL service;
	
	public RestController() {
		System.out.println("rest controller");
	}
	
	@RequestMapping(value = "/list/releases", method = RequestMethod.GET)
    public ResponseEntity<List<Release>> listAllUsers() {
        List<Release> releaseList = service.fingAllRelease();
        for (Release release : releaseList) {
			System.out.println(release);
		}
        if(releaseList.isEmpty()){
            return new ResponseEntity<List<Release>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
        }
        return new ResponseEntity<List<Release>>(releaseList, HttpStatus.OK);
    }
	
	
	
	@RequestMapping(value = "/home")
	public String homepgae()
	{
		System.out.println("in Show Home");
		return "homepage";
	}

	//service to get all release to
	@RequestMapping(value = "/list/releaseto", method = RequestMethod.GET)
    public ResponseEntity<List<ReleaseTo>> listReleaseTo() 
	{
		System.out.println("List release to function");
        List<ReleaseTo> releaseToList = service.getReleaseTo();
        for (ReleaseTo to : releaseToList) {
			System.out.println(to);
		}
        if(releaseToList.isEmpty()){
            return new ResponseEntity<List<ReleaseTo>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
        }
        return new ResponseEntity<List<ReleaseTo>>(releaseToList, HttpStatus.OK);
    }
	
	//service to get all release type
		@RequestMapping(value = "/list/releasetype", method = RequestMethod.GET)
	    public ResponseEntity<List<ReleaseType>> listReleaseType() 
		{
			System.out.println("List release type function");
	        List<ReleaseType> releaseTypeList = service.getReleaseType();
	        for (ReleaseType type : releaseTypeList) {
				System.out.println(type);
			}
	        if(releaseTypeList.isEmpty()){
	            return new ResponseEntity<List<ReleaseType>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
	        }
	        return new ResponseEntity<List<ReleaseType>>(releaseTypeList, HttpStatus.OK);
	    }
	
	//service to get all release status
		@RequestMapping(value = "/list/releasestatus", method = RequestMethod.GET)
	    public ResponseEntity<List<ReleaseStatus>> listAllCatgories() 
		{
			System.out.println("List status function");
	        List<ReleaseStatus> statusList = service.getRelesaseStatus();
	        for (ReleaseStatus status : statusList) {
				System.out.println(status);
			}
	        if(statusList.isEmpty())
	        {
	            return new ResponseEntity<List<ReleaseStatus>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
	        }
	        return new ResponseEntity<List<ReleaseStatus>>(statusList, HttpStatus.OK);
	    }
		
	//service to add release /list/newRelease
		
		@RequestMapping(value = "/newRelease", method = RequestMethod.POST)
	    public ResponseEntity<List<ReleaseItem>> createRelease(@RequestBody List <ReleaseItem> releaseItems,UriComponentsBuilder ucBuilder) 
		{
	        System.out.println("Creating new release ");
	        
	        for (ReleaseItem releaseItem : releaseItems) {
				System.out.println("items   : " + releaseItem);
			}

	        //service.saveCategory(category);
	 
	        HttpHeaders headers = new HttpHeaders();
	        return new ResponseEntity<List<ReleaseItem>>(headers, HttpStatus.CREATED);
		}
		
	
/*	@RequestMapping(value = "/newCategory", method = RequestMethod.POST)
    public ResponseEntity<Void> createUser(@RequestBody Category category,UriComponentsBuilder ucBuilder) {
        System.out.println("Creating Category " + category.getCategoryName());

        service.saveCategory(category);
 
        HttpHeaders headers = new HttpHeaders();
        return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
    }*/
 
}
