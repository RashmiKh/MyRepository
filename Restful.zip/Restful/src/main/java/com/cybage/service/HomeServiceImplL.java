package com.cybage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.dao.HomeDaoL;
import com.cybage.model.Release;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;

@Service
public class HomeServiceImplL implements HomeServiceL 
{
	@Autowired
	HomeDaoL dao;
	
	public HomeServiceImplL() {
		System.out.println("Service");
	}
	
	@Override
	public List<Release> fingAllRelease() 
	{
		return dao.fingAllRelease();
	}

	@Override
	public List<ReleaseStatus> getRelesaseStatus()
	{
		return dao.getRelesaseStatus();
	}

	@Override
	public List<ReleaseType> getReleaseType() 
	{		
		return dao.getReleaseType();
	}

	@Override
	public List<ReleaseTo> getReleaseTo() 
	{
		return dao.getReleaseTo();
	}

	/*@Override
	public List<Category> getCategories() 
	{
		return dao.getCategories();
	}

	@Override
	public Integer saveCategory(Category category)
	{		
		return dao.saveCategory(category);
	}*/

}
