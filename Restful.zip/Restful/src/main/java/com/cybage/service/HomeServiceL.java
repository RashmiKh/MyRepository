package com.cybage.service;

import java.util.List;

import com.cybage.model.Release;
import com.cybage.model.ReleaseStatus;
import com.cybage.model.ReleaseTo;
import com.cybage.model.ReleaseType;

public interface HomeServiceL 
{
	List<Release> fingAllRelease();/*
	List<Category> getCategories();
	Integer saveCategory(Category category);*/
	List<ReleaseType> getReleaseType();
	List<ReleaseTo> getReleaseTo();
	List<ReleaseStatus> getRelesaseStatus();
}
