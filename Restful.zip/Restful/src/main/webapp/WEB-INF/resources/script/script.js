
var items = [];

app.service('dataService', ['$http', function ($http) 
{
	var urlBase = 'http://localhost:8080/Restful/home';
	
	this.getReleaseType = function()
    {
    	return $http.get(urlBase + "/list/releasetype");
    };
	
    this.getReleaseTo = function()
    {
    	return $http.get(urlBase + "/list/releaseto");
    };
    
	this.getReleaseStatus = function()
    {
    	return $http.get(urlBase + "/list/releasestatus");
    };
    
    this.addNewRelease = function(newRelease)
    {
    	return $http.post(urlBase + "/newRelease", newRelease);
    };
                                
}]);

app.controller("AddReleaseController",function($scope, dataService)
{
	/*console.log($scope.release.releasetype.id);*/
	dataService.getReleaseType()
    .then(function (response) 
    {
        $scope.releasetypes = response.data;
        console.log($scope.releasetypes);
    }, function (error)
    {
        $scope.status1 = 'Unable to load release types: ' + error.message;
    });
	
	dataService.getReleaseTo()
    .then(function (response) 
    {
        $scope.releaseto = response.data;
    }, function (error)
    {
        $scope.status2 = 'Unable to load release to: ' + error.message;
    });
	
	dataService.getReleaseStatus()
    .then(function (response) 
    {
    	var r = response.data;
        $scope.releasestatus = response.data;
    }, function (error)
    {
        $scope.status3 = 'Unable to load release status: ' + error.message;
    });
	
	$scope.addItem = function()
	{
		window.alert("fgdfg");
		items.push($scope.item);
		$scope.item = "";
		/*for(var i=0;i<items.length;i++)
		{
			window.alert(items[i].name);
		}*/
	};
	
	$scope.addRelease = function()
	{
		console.log("releaseT : " + angular.fromJson($scope.release.releaseType));
		var releaseItems = [];
		for(var i in items){
			releaseItem = {release: $scope.release, item: items[i]};
			releaseItems.push(releaseItem);
		}
		for(var i in releaseItems){
			console.log(releaseItems[i]);
		}
		dataService.addNewRelease(releaseItems)
        .then(function (response)
        {
            window.alert("response send..");
        }, function(error) {
            $scope.status = 'Unable to insert customer: ' + error.message;
        });
	}
})