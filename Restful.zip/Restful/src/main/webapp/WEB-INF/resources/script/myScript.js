
var studentArray = [
					{name:'Raj',city:'Pune'},
					{name:'Meera',city:'Mumbai'},
					{name:'Rohit',city:'Banglore'},
					{name:'Neeta',city:'Nagpur'}
			   ];


			   
 mainApp.controller('ViewStudentsController', ['$scope', function($scope) {
	
	$scope.students=studentArray;
	
 }]);
 
 mainApp.controller('AddStudentController',['$scope', function($scope) {
	 
	  $scope.addStudent = function()
	 {
		 studentArray.push({ name: $scope.student.name, city: $scope.student.city });
		 $scope.message = "Student entry added";
		 $scope.student.name = '';
		 $scope.student.city = '';
	 } 
 }]);
 

	