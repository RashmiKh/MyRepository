var mainApp = angular.module("mainApp", ['ngRoute']);
mainApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
    when('/addStudent', {
      templateUrl: 'add.jsp',
      controller: 'AddStudentController'
    }).
    when('/viewStudents', {
      templateUrl: 'view.jsp',
      controller: 'ViewStudentsController'
    }).
    otherwise({
      redirectTo: '/viewStudents'
    });
  }
]);